abstract class Car {
    private String brand;

    public Car(String brand) {
        this.brand = brand;
        construct();
    }

    protected abstract void construct();
    public String getBrand() {
        return brand;
    }
}