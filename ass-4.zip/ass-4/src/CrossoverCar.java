public class CrossoverCar extends Car {
    CrossoverCar(String brand) {
        super(brand);
    }

    @Override
    protected void construct() {
        System.out.println("A `crossover` car model of the " + getBrand() + " brand was released.");
    }
}