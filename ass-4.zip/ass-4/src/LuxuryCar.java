public class LuxuryCar extends Car {
    LuxuryCar(String brand) {
        super(brand);
    }

    @Override
    protected void construct() {
        System.out.println("A `luxury` car model of the " + getBrand() + " brand was released.");
    }
}
