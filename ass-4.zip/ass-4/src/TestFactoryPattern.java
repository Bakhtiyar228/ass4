import java.util.Random;
import java.util.Scanner;

public class TestFactoryPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Car Factory!");
        System.out.println("----------------------------");
        System.out.println("Choose a car type to release:");
        for (CarType carType : CarType.values()) {
            System.out.println(carType);
        }
        System.out.print("Enter the car type: ");
        String carTypeInput = scanner.nextLine().toUpperCase();
        CarType carType;
        try {
            carType = CarType.valueOf(carTypeInput);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid car type. Please choose from the options provided.");
            scanner.close();
            return;
        }
        System.out.print("Enter the brand for the car: ");
        String brand = scanner.nextLine();
        CarFactory.buildCar(carType, brand);
        int randomPrice = (int) generateRandomPrice();
        System.out.println("Price: $" + randomPrice);
        System.out.println("Thank you for choosing the Car Factory!");
    }
    private static double generateRandomPrice() {
        Random random = new Random();
        return 10000 + random.nextDouble() * 190000;
    }
}