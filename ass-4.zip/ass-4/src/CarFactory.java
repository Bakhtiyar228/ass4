public class CarFactory {
    public static Car buildCar(CarType model, String brand) {
        Car car = null;
        switch (model) {
            case CROSSOVER:
                car = new CrossoverCar(brand);
                break;
            case SEDAN:
                car = new SedanCar(brand);
                break;
            case LUXURY:
                car = new LuxuryCar(brand);
                break;
            default:
                break;
        }
        return car;
    }
}