public class SedanCar extends Car {
    SedanCar(String brand) {
        super(brand);
    }
    @Override
    protected void construct() {
        System.out.println("A `sedan` car model of the `" + getBrand() + "` brand was released.");
    }
}