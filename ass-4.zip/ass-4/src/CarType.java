public enum CarType {
    CROSSOVER, SEDAN, LUXURY;
}